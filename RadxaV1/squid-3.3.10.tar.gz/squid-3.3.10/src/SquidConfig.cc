#include "squid.h"
#include "SquidConfig.h"

class SquidConfig Config;

class SquidConfig2 Config2;

